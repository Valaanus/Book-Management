import Navbar from '../Navbar'
import React, { Component } from 'react';

import '../FrontPages/Home.css';
 
function Home() {
  return (
    <div>
      <Navbar />
      <div className='about-img'>
       
      </div>
    </div>
  )
}

export default Home;