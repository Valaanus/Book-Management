import React from 'react';

import "./Buttons.css";

function Buttons() {

    return (
          
 <div className='backgroundImg43'> 
       <div className="container">  
            <div className="center">
                <div><a href="/login"><button className='button1'>Login</button></a>
                <a href="/register"><button className='button2'>Register</button></a></div><br/> 
            </div>   
        </div>
        </div>
    );
}

export default Buttons;